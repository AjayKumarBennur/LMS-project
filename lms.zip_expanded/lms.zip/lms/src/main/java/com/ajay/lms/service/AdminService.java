package com.ajay.lms.service;

import com.ajay.lms.pojo.BatchDetails;
import com.ajay.lms.pojo.Mentor;

public interface AdminService {
	
	public BatchDetails addBatch(BatchDetails details);

	public BatchDetails update(BatchDetails details,int id);

	public void delete(Integer id);

	public Mentor addMentor(Mentor mentor);
	
}
