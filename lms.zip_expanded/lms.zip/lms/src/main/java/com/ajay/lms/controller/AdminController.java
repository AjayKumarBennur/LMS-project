package com.ajay.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ajay.lms.pojo.BatchDetails;
import com.ajay.lms.pojo.Mentor;
import com.ajay.lms.pojo.ResponseBody;
import com.ajay.lms.service.AdminService;

@RestController
@RequestMapping("/lms/admin/api")
public class AdminController {
	
	@Autowired
	AdminService service;
	
	@PostMapping("/batch")
	public ResponseEntity<ResponseBody> addBatch(@RequestBody BatchDetails details) {
		BatchDetails addBatch = service.addBatch(details);
		return new ResponseEntity<>(new ResponseBody(false, "Success", addBatch), HttpStatus.OK);
	}
	
	@PutMapping("/batch/{id}")
	public ResponseEntity<ResponseBody> updateBatch(@RequestBody BatchDetails details,@PathVariable Integer id) {
		return new ResponseEntity<>(new ResponseBody(false, "Success",service.update(details, id)),HttpStatus.OK);
	}
	
	
	@DeleteMapping("/batch/{id}")
	public ResponseEntity<ResponseBody> delete(@PathVariable Integer id) {
		if(id==null) {
			throw new RuntimeException();
		}
		return new ResponseEntity<>(new ResponseBody(false, "Success", null),HttpStatus.OK);
	}
	
	@PostMapping("/mentor")
	public ResponseEntity<ResponseBody> addMentor(@RequestBody Mentor mentorDetails){
		Mentor addMentor = service.addMentor(mentorDetails);
		ResponseBody body = new ResponseBody(false, "successfull", addMentor);
		return new ResponseEntity<ResponseBody>(body, HttpStatus.OK);
	}
	
	
	
}
