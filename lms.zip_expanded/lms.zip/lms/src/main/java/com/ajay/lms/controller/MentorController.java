package com.ajay.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ajay.lms.pojo.Employee;
import com.ajay.lms.pojo.Mock;
import com.ajay.lms.pojo.MockRatings;
import com.ajay.lms.pojo.ResponseBody;
import com.ajay.lms.service.MentorService;

@RestController
@RequestMapping("/api/mentor")
public class MentorController {

	@Autowired
	private MentorService service;

	@GetMapping("/batchdetails/{batchName}")
	public ResponseEntity<ResponseBody> getBatchDetails(@PathVariable String batchName) {
		List<Employee> allEmployee = service.getAllEmployee(batchName);
		return new ResponseEntity<>(new ResponseBody(false, "Success", allEmployee), HttpStatus.OK);
	}
	
	@GetMapping("/employeeDetails/{empId}")
	public ResponseEntity<ResponseBody> getDetailsOfEmployee(@PathVariable String empId){
		List<MockRatings> details = service.getEmployeeDetails(empId);
		return new ResponseEntity<>(new ResponseBody(false, "Mock Rating of a employee", details),HttpStatus.OK);
		
	}
	
	@PostMapping("/mock")
	public ResponseEntity<ResponseBody> addMock(@RequestBody Mock mock){
		Mock createMock = service.createMock(mock);
        return	new ResponseEntity<>(new ResponseBody(false, "Mock created", createMock), HttpStatus.OK);
	}

}
