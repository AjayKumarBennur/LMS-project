package com.ajay.lms.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajay.lms.pojo.BatchDetails;
import com.ajay.lms.pojo.Employee;
import com.ajay.lms.pojo.Mock;
import com.ajay.lms.pojo.MockRatings;
import com.ajay.lms.repo.BatchDetailsRepo;
import com.ajay.lms.repo.EmployeeRepo;
import com.ajay.lms.repo.MockRepo;

@Service
public class MetnorServiceImpl implements MentorService{

	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private BatchDetailsRepo batchDetailsRepo;
	
	@Autowired
	private MockRepo mockRepo;
	
	@Override
	public List<Employee> getAllEmployee(String batchName) {
		System.out.println("id---------------->"+batchDetailsRepo.findIdByBatchName(batchName));
		BatchDetails batch = batchDetailsRepo.findIdByBatchName(batchName);
		return batch.getEmployees();
	}

	@Override
	public List<MockRatings> getEmployeeDetails(String empId) {
		Employee empDetails = empRepo.findByEmpId(empId);
		return empDetails.getRatings();
	}

	@Override
	public Mock createMock(Mock mock) {
		return mockRepo.save(mock);
		
	}
	
}
