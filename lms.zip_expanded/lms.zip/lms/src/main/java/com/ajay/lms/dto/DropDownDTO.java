package com.ajay.lms.dto;

import lombok.Data;

@Data
public class DropDownDTO {
	
	private Integer id;
	private String name;
	
}
