package com.ajay.lms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajay.lms.pojo.BatchDetails;
import com.ajay.lms.pojo.Mentor;
import com.ajay.lms.repo.BatchDetailsRepo;
import com.ajay.lms.repo.MentorRepo;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private BatchDetailsRepo batchRepo;
	
	@Autowired
	private MentorRepo mentorRepo;
	

	@Override
	public BatchDetails addBatch(BatchDetails details) {
		return batchRepo.save(details);
	}

	@Override
	public BatchDetails update(BatchDetails details,int id) {
		BatchDetails existing = batchRepo.findById(id).get();
		if(existing==null) {
			throw new RuntimeException();
		}
		existing.setBatchName(details.getBatchName());
		existing.setEndDate(details.getEndDate());
		existing.setMentor(details.getMentor());
		existing.setStatus(details.getStatus());
		existing.setTechnologies(details.getTechnologies());
		return existing;
	}

	@Override
	public void delete(Integer id) {
		batchRepo.deleteById(id);
	}

	@Override
	public Mentor addMentor(Mentor mentor) {
		Mentor save = mentorRepo.save(mentor);
		if(save==null) {
			throw new RuntimeException();
		}
		return save;
	}

}
